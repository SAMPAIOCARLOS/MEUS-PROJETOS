<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="style.css"> -->

    <?php wp_head(); ?>
</head>
<body>
    <header class="header">
        <div class="mancha-left">
        </div>

        <div class="bnc_one">
            <img src="imgs/Ativo 4teste.png" alt="" class="imgs">
        </div>

        <div class="logo_ma">
            <img src="imgs/mog_gov_borda_SEEJUV_P.png" alt="" class="imgs">
        </div>

        <div class="img_center">
            <img src="imgs/Ativo 7teste.png" alt="" class="imgs testeimg">
        </div>


        <div class="bnc_two">
            <img src="imgs/Ativo 5teste.png" alt="" class="imgs">
        </div>

        <div class="bnc_three">
            <img src="imgs/Ativo 3teste.png" alt="" class="imgs">
        </div>

        <div class="container_mancha_right">
            <div class="mancha-right">
            </div>
        </div>
    </header>

    <nav class="nav">
        <div id="container-buttons">
            <button class="buttons">INSTITUCIONAL</button>
            
            <button class="buttons">AÇÕES PRESENCIAIS</button>
            
            <button class="buttons">ORIENTAÇÕES</button>
            
            <button class="buttons">FOTOS</button>
        </div>
    </nav>