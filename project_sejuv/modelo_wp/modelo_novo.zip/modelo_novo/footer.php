<footer class="footer">
        <div class="container_infor_footer">
            <div id="address">
                <p>Secretaria De Estado Extraordinária da Juventude <br>
                    Av. Pedro II, N° 199 - Centro, São Luís - MA, 65010-450</p>
            </div>

            <div id="contact">
                <p><strong>Contato</strong> <br>
                    +55 98 98466-7812 <br>
                    ascom@seejuv.ma.gov.br</p>
            </div>
        </div>

        <div class="container_icons_social">
            <ion-icon name="logo-whatsapp" class="icons_social"></ion-icon>

            <ion-icon name="logo-instagram" class="icons_social"></ion-icon>

            <ion-icon name="logo-facebook" class="icons_social"></ion-icon>
        </div>
    </footer>

    <?php wp_footer(); ?>
</body>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

<!-- <script src="script.js"></script> -->

</html>